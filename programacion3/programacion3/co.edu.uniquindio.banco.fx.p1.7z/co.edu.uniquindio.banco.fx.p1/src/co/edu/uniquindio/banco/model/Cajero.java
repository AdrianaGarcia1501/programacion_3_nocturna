package co.edu.uniquindio.banco.model;

public class Cajero extends Empleado{

	public Cajero() {
		// TODO Auto-generated constructor stub
	}
}
