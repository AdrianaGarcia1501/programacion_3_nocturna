package co.edu.uniquindio.banco.model;

public class Deposito extends Transaccion{
	
	public Deposito() {
		// TODO Auto-generated constructor stub
	}

}
