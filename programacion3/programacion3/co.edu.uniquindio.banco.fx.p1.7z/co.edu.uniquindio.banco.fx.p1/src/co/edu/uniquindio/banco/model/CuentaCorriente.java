package co.edu.uniquindio.banco.model;

public class CuentaCorriente extends Cuenta{
	
	public CuentaCorriente() {
		// TODO Auto-generated constructor stub
	}

}
