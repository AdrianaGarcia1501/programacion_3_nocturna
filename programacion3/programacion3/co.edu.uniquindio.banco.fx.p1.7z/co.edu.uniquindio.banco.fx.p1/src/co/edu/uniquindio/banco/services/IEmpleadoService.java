package co.edu.uniquindio.banco.services;

public interface IEmpleadoService {
	
	public void devolverEdad();

}
