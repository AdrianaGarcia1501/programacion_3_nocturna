package co.edu.uniquindio.banco.controllers;

public class EmpleadoException extends Exception {
	
	public EmpleadoException(String mensaje) {
		super(mensaje);
	}
}
