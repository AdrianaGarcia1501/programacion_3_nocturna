package co.edu.uniquindio.banco.model;

import java.io.Serializable;

public class Cajero extends Empleado implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Cajero() {
		// TODO Auto-generated constructor stub
	}
}
