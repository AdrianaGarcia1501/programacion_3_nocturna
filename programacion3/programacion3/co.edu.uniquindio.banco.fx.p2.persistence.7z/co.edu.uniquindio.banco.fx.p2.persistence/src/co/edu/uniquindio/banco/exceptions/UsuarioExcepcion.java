package co.edu.uniquindio.banco.exceptions;

public class UsuarioExcepcion extends Exception{
	
	public UsuarioExcepcion(String mensaje) {
		super(mensaje);
	}
}
