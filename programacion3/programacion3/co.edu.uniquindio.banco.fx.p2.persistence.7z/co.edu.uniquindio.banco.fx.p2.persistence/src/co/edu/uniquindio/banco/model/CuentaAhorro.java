package co.edu.uniquindio.banco.model;

import java.io.Serializable;

public class CuentaAhorro extends Cuenta implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CuentaAhorro() {
		// TODO Auto-generated constructor stub
	}
}
