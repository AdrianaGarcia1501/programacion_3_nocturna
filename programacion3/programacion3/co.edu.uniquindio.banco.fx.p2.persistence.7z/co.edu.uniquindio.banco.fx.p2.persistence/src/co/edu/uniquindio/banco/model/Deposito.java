package co.edu.uniquindio.banco.model;

import java.io.Serializable;

public class Deposito extends Transaccion implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Deposito() {
		// TODO Auto-generated constructor stub
	}

}
