package co.edu.uniquindio.banco.model;

import java.io.Serializable;

public class Retiro extends Transaccion implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Retiro() {
		// TODO Auto-generated constructor stub
	}
}
