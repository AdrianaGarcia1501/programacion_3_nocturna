package co.edu.uniquindio.banco.services;

public interface ICuentaService {

	public void retirarDinero (Double cantidad);
	
	
}
