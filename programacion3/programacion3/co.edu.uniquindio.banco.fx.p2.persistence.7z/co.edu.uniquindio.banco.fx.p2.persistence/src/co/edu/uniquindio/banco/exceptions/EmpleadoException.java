package co.edu.uniquindio.banco.exceptions;

public class EmpleadoException extends Exception{
	
	public EmpleadoException(String mensaje) {
		super(mensaje);
	}

}
